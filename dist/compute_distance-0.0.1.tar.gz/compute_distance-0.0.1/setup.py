from setuptools import setup, find_packages

setup(
    name="compute_distance",
    version="0.0.1",
    package= find_packages(),
    install_requires=[],
    author="koomi",
    description="distance between individual and the centroid of less engaged or experienced group"
    # long_description=open("README.md").read(),
    # long_description_content_type="text/markdown",
)